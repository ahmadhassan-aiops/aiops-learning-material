Please run setup.exe to install inSSIDer. It will check for prerequisites and download or send you to the correct URL to download and install any missing prerequisites.

If you have any issues or questions please visit the inSSIDer forum at:

http://www.metageek.net/forums/forumdisplay.php?4615-inSSIDer